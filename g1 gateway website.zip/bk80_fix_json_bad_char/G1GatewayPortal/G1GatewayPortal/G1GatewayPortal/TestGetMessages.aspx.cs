﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PPOMManager;
using System.Configuration;
using System.Data;

namespace G1GatewayPortal
{
    public partial class TestGetMessages : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CallProc_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ppomLinksConnectionString"].ToString();
            PPOMAccess ppomAccess = new PPOMAccess();
            string errorMessage = "";
            DataTable dt = ppomAccess.GetPPOMMessagesFromDB("PPOM", connectionString, ref errorMessage);
            if (dt == null)
                if (!String.IsNullOrEmpty(errorMessage))
                {
                    ShowRowCount.Text = errorMessage;
                }
                else
                {
                    ShowRowCount.Text = "null";
                }
            else
                ShowRowCount.Text = dt.Rows.Count.ToString();
        }
    }
}