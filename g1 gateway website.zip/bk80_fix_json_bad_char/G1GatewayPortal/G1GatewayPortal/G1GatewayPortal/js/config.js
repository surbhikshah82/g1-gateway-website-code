﻿var configItems = {
    getPPOMMessagesURL: "http://localhost/G1GatewayPortal/G1GatewayWebService.asmx/GetPPOMMessages",
    displayPPOMDataURLBase: "http://localhost/DisplayPDF/DisplayPPOM.aspx",
    helpDeskPhone: "1-844-340-8843",
    //set to 2012 for dev environment

    ppomCurrentYear: 2012     // set to 0 to use the current year, otherwise set the year for the left-most PPOM tile

}







