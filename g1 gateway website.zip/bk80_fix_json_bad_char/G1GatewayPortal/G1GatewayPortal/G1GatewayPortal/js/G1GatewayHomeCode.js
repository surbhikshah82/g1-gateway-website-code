﻿// Initial creation on 6/5/2017 by Barry Gruber
// The code in this file works to display menus and menu item targs for the G1GatewayHome.html page.

function init() {
    // gdalert("step 19");
    displayXML();
    document.getElementById("txtppomSearch").value = "";
    ppomManager.setPPOMEventHandlers();
}

//var starttime; // for timing, leave as comment out
//var finishtime; // for timing, leave as comment out

// global variables 
var g_xml;                  // Holds xml read from file. Used to get xml into event handler
var currentYear;            // Holds current calendar year. This is the default year for the left-most PPOM tile.
var yearTextSet = false;    // If false, set the text for the PPOM year tiles.
var numPPOMYears = 5;       // Number of PPOM tiles with a numeric year (this excludes "Other" and "All)
var ppomRows;               // Holds array of objects containing PPOM data from call to DB proc smms.GetMessages
                            // each object in one row contains the value from a column returned by the proc.
var ppomYears = {           // The ppomYears object holds a set of arrays, each corresponding to one of the PPOM years.
    year0: [],              // The indices to the PPOM rows returned from the database are added to each of these arrays
    year1: [],              // by traversing the datarows returned from the database call.
    year2: [],
    year3: [],
    year4: [],
    yearOther: [],
    searchHits: []
};

function displayXML() {
    //starttime = new Date();   // for timing, leave as comment out

    // without hiding the link area, a gray bar (part of the link area) displays under the tiles. 
    // This is not needed, so hide it.
    document.getElementById("linkArea").className = "hideDiv";

    // use Ajax to read the xml file G1GatewayMenuLinks.xml, and use callback function showTheList
    // to process the xml from the file.
    var oXHR = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

    function reportStatus() {
        if (oXHR.readyState == 4)               // REQUEST COMPLETED.
            showTheList(this.responseXML);      // ALL SET. NOW SHOW XML DATA.
    }

    oXHR.onreadystatechange = reportStatus;
    oXHR.open("GET", "G1GatewayMenuLinks.xml", true);      // true = ASYNCHRONOUS REQUEST (DESIRABLE), false = SYNCHRONOUS REQUEST.
    oXHR.send();
}

function showTheList(xml) {
    // in case we ever need to time how long it takes to load the xml
    //finishtime = new Date();
    //alert("XML load time: " + (finishtime.getMilliseconds() - starttime.getMilliseconds()));

    // This function is the event handler (callback) for the Ajax call to read all the xml in G1GatewayMenuLinks.xml. The xml
    // parameter represents the complete xml text from the file.

    // The function parses the xml and based on the XML elements and attributes, writes HTML to a div, where there is one div
    // for each of the 4 menus.

    // In each menu (e.g., Policies and Regulations) , there are one or more menu item groups (e.g., Policies Library), and each of 
    // the menu item groups contains 0 or more menu items. The menu item group may be clickable and may not have any content
    // (e.g., A-Z List in the HR Programs... menu).

    // Each of the 4 menus is written as an <ul> element, and each clickable item (Menu Item Group or Menu Item) is written out 
    // as an <li> element in the <ul>.

    // The variables here are used in loops below. See comments in the looping
    // code that explain what the variables are.
    var menu;
    var divInnerHTML;
    var divID;
    var menuDiv;
    var menuClass;          // holds css class of each menu element
    var menuItemGroups;
    var menuItemGroup;
    var menuItemGroupID;
    var menuItemGroupText;
    var menuItemGroupURL;
    var menuItems;
    var menuItem;
    var menuItemText;
    var menuItemURL;
    var menuItemID;
    var menuItemGroupClass;
    var menuItemTypeExternal;
    var targetAttribute;
    var eventHandlerSetup;
    var menuItemClickHandler;

    g_xml = xml;
    var menus = xml.getElementsByTagName("Menu");
    
    for (var i = 0; i < menus.length; i++) {
        // process each Menu element
        menu = menus[i];
                
        // set menu class
        menuClass = menu.getAttribute("class");
        
        // get html page div id from XML - this is different for each menu, 
        // and use this to get the div from the HTML page
        divId = menu.getAttribute("divId");
        menuDiv = document.getElementById(divId);
        menuDiv.setAttribute("class", menuClass);

        // create text for each div, start by setting it an empty string
        divInnerHTML = "";      // holds all text and formatting for the current menu
        divInnerHTML = "<ul><li><span class='menuText'>" + menu.getAttribute("MenuText") + "</span></li>";

        /////////////////////////////////////////////////////////////////////
        // now get and generate text for each MenuItemGroup                
        menuItemGroups = menu.getElementsByTagName("MenuItemGroup");

        for (var j = 0; j < menuItemGroups.length; j++) {
            menuItemGroup = menuItemGroups[j];
            menuItemGroupID = menuItemGroup.getAttribute("id");
            menuItemGroupURL = menuItemGroup.getAttribute("MenuItemGroupURL");
            menuItemGroupText = menuItemGroup.getAttribute("MenuItemGroupText");
            menuItemGroupClass = menuItemGroup.getAttribute("class");

            if (menuItemGroupClass != "menuItemGroupHidden") {
                divInnerHTML += "<li><span class='" + menuItemGroupClass + "'>";
                if (menuItemGroupURL != "") {
                    eventHandlerSetup = " onclick=' return handleMenuClick(\"" + menuItemGroupID + "\");'"
                    divInnerHTML += "<a" + eventHandlerSetup + " href='" + menuItemGroupURL + "'>" +
                    menuItemGroupText + "</a></span></li>";
                } else {
                    divInnerHTML += menuItemGroupText + "</span></li>";
                }
            }

            //////////////////////////////////////////////////////////////////
            // within each MenuItemGroup, now display each menu item
            menuItems = menuItemGroup.getElementsByTagName("MenuItem");
            for (var k = 0; k < menuItems.length; k++) {
                menuItem = menuItems[k];
                menuItemID = menuItem.getAttribute("id");

                // Most items have a null value for menuItemClickHandler and use the default handler that
                // will be set if the menuItemClicker is null.
                // As of 7/26/17, only the PPOM menu item and Home menu item has a special handler.
                menuItemClickHandler = menuItem.getAttribute("clickHandler");
                menuItemText = menuItem.getElementsByTagName("Text")[0].childNodes[0].nodeValue;
                menuItemURL = menuItem.getElementsByTagName("URL")[0].childNodes[0].nodeValue;

                // get attribute "type" to see if the URL is for an external link and if it is,
                // added a _blank target attribute to the <a> tag
                menuItemTypeExternal = menuItem.getAttribute("type");
                if (menuItemTypeExternal) {
                    targetAttribute = " target = '_blank'";
                } else {
                    targetAttribute = "";
                }

                // add the event handler for the menu item
                switch (menuItemClickHandler) {
                    case "handleMenuClickForPPOM":
                        eventHandlerSetup = " onclick=' return handleMenuClickForPPOM(this);'";
                        break;
                    case "handleMenuClickForHome":
                        eventHandlerSetup = " onclick=' return handleMenuClickForHome(this);'";
                        break;
                    default:
                        eventHandlerSetup = " onclick=' return handleMenuClick(this);'";
                        break;
                }

                divInnerHTML += "<li><span class='menuItem' id='" + menuItemID + "'>" +
                    "<a" + targetAttribute + eventHandlerSetup + " href='" + menuItemURL + "'>"
                    + menuItemText + "</a></span></li>";
            }
        }
        menuDiv.innerHTML = divInnerHTML + "</ul>";
    }
}

function handleMenuClick(anchorTagItem) {
    // As of 7/27/2017 there are six different 'types' of clickable menu items. The types determine 
    // the resulting behavior of what is displayed and what happens to the tiles. The types as defined
    // by the esulting behavior are:
    // 1) Internal content is displayed in the link area; tiles are hidden.
    // 2) Internal content is missing so an 'under contruction message'  is displayed in the link area; 
    //    tiles are hidden.
    // 3) Internal content is displayed in a new tab; tiles are not hidden.
    // 4) External content (not in the original Sharepoint site) is displayed in a new tab; this includes "site not
    //    found or site not available. Current link area content is not hidden; tiles are not hidden.
    // 5) Internal content (from the original Sharepoint site) is not displayed because the Sharepoint site
    //    has been taken down. An 'under construction' message is displayed in the link area; 
    //    tiles are hidden.
    // 6) Clicking on 'Display Tiles' in the Home menu results in hiding the link area and displaying
    //    the tiles.

    // The anchorTagItem parameter is the <a> tag the user clicked on
    // "la" at the beginning of variable names stands for link area

    var menuItems;      // holds all MenuItem elements from XML
    var menuItem;       // container for all link area items in XML for the menu item that was clicked
    
    var laItemGroup;    // a grouping of links in the link area. An example is the links under
                        // the text "Non-Regular Retirement Calculators" after the user clicks
                        // on "Resource Center / Calculators
    var laItemGroupText;
    var laItem;         // contains 1 link and additional text
    var laItemText;
    var laItemURL;
    var laItemDesc;
    var divInnerHTML = "";  // holds html that is being put together after parsing html
    var targetAttribute = " target = '_blank'";
    var samePageLinkBase = " onclick='return false' class=NoClick";
    var samePageLink;       // dynamically set to samePageLinkBase or an empty string
    var i;              // this counter is used in more than 1 loop
    var linkAreaPage;   // contains link area items from one page in the original G1 Gateway app
    var linkAreaPages;  // collection of <LinkAreaPage> items
    var linkAreaPageText;
    var addBr;
    var itemNameForBadLink;
    var menuItemTypeExternal = "";


    // step 1: get the <MenuItem> element from the XML corresponding to the menu item that was clicked

    // Div that holds all content for links after user clicks on a menu item (excluding external links)
    var linkAreaDiv = document.getElementById("linkArea");

    // laContainerId is the id of the XML MenuItem node containing the <a> tag that was clicked
    var laContainerId = anchorTagItem.parentNode.getAttribute("id");

    // get all the MenuItem elements (note that JavaScript doesn't support a getElementById for an XML DOM)
    menuItems = g_xml.getElementsByTagName("MenuItem");

    // go through all the menuItems, looking for the one with the ID corresponding to the ID containing the <a> tag
    for (i = 0; i < menuItems.length; i++) {
        if (menuItems[i].getAttribute("id") == laContainerId) {
            menuItem = menuItems[i];
            break;
        }
    }

        // step 2 - Read the xml contained in the <MenuItem> element from step 1 and display it

    // Get the program/process category and display it (if it exists)
    // The category is a program category or process category that corresponds to a page
    // that is displayed (in the original G1 Gateway app) when the user clicks on a menu item
    // in the "HR Programs, Processes and Systems menu). This is not displayed when 
    // menu items in other menus are clicked.
    var category = menuItem.getAttribute("category");
    if (category != null) {
        divInnerHTML += "<h2>" + category + "</h2>";
    }

    // get all the <LinkAreaPage> items for the selected menu 
    linkAreaPages = menuItem.getElementsByTagName("LinkAreaPage");
    for (i = 0; i < linkAreaPages.length; i++) {
        linkAreaPage = linkAreaPages[i];
        linkAreaPageText = linkAreaPage.getAttribute("text");
        divInnerHTML += "<h3>" + linkAreaPageText + "</h3>";

        // now get the LinkAreaItemGroup collection for each <LinkAreaPage> element
        var linkAreaItemGroups = linkAreaPage.getElementsByTagName("LinkAreaItemGroup");
        for (var j = 0; j < linkAreaItemGroups.length; j++) {
            // for each laItemGroup, get the text and all the laItems it contains
            laItemGroup = linkAreaItemGroups[j];
            laItemGroupText = laItemGroup.getAttribute("text");
            divInnerHTML += "<ul><li class='LAItemGroup'><p>" + laItemGroupText + "</p></li>"

         
            laItems = laItemGroup.getElementsByTagName("LA_Item");
            for (var k = 0; k < laItems.length; k++) {
                laItem = laItems[k];
                laItemURL = laItem.getElementsByTagName("LA_URL")[0].childNodes[0].nodeValue;
                laItemText = laItem.getElementsByTagName("LA_Text")[0].childNodes[0].nodeValue;

                // Even if there is no description for display, the LA_Item element will contain an
                // empty <LA_Desc> element. Test for whether the tag is not empty by testing if
                // first child node of the tag is not null. If the tag is empty, set laItemDesc to an
                // empty string so more logic can be done below.
                if (laItem.getElementsByTagName("LA_Desc")[0].childNodes[0] != null) {
                    laItemDesc = laItem.getElementsByTagName("LA_Desc")[0].childNodes[0].nodeValue;
                } else
                    laItemDesc = "";


                if (laItemURL.length <= 1) {
                    samePageLink = samePageLinkBase;
                } else {
                    samePageLink = ""
                }

                if (laItemText != " ") {
                    divInnerHTML += "<li class='LAItem'><a " + targetAttribute + samePageLink + " href='" + laItemURL + "'>" + laItemText + "</a>";

                } else {
                    divInnerHTML += "<li class='LAItem' >"
                }

                // if the Desc is not blank, insert it into the <li> tag. And if the URL is bigger than one character
                // add a new line before the Desc. Note that the <LA_URL> tag (in the XML) contains the URL, and contains
                // one space if there is no <a> tag and URL to be displayed.
                addBr = true;
                if (laItemDesc != "") {
                    if (laItemDesc.indexOf("</p>") >= 0) {
                        addBr = false;
                    }
                    if (laItemURL.length > 1 || laItemText != " ") {
                        divInnerHTML += "<br />";
                    }
                    divInnerHTML += "<span>" + laItemDesc + "</span></li>";

                } else {
                    divInnerHTML += "</li>";
                }

                // Add an empty line if the current LA_Item is not the last one.
                if (k < (laItems.length - 1) && addBr ) {
                    divInnerHTML += "<br />";
                }
            }
            divInnerHTML += "</ul>";
        }
    }
    
    // For links that don't point to active internal content or point to a page
    // in the old G1 SharePoint site, display the under Construction message as internal content.
    // The sidebar/tile items all have a linkAreaPages.length of 0, so also need to check the href attribute.
    
    if (linkAreaPages.length == 0 && anchorTagItem.getAttribute("href") == "#") {
        if (anchorTagItem.text == "") {
            itemNameForBadLink = anchorTagItem.getAttribute("id");
        } else {
            itemNameForBadLink = anchorTagItem.text;
        }
        divInnerHTML += "<h3>" + itemNameForBadLink + " is under renovation</h3><ul><li class='LAItemGroup'><p>" +
            "The Army National Guard G1 Personnel Gateway website is undergoing renovation. " +
            "The item you have selected is currently inactive. Please check back later " +
            "for updates.</p></li><li class='LAItem'><span><div style='height:209px;'>" +
            "</span></li></ul>";
        // For items that had were displays as external page, change the target
        // attribute so the under construction is displayed as intenal content.
        anchorTagItem.setAttribute("target", "");
    }

    // hide the tiles / ARNG logo before displaying the content
    //var logo = document.getElementById("arngLogo");
    //logo.className = "hideOnFirstClick";
    menuItemTypeExternal = menuItem.getAttribute("type");
    var tilesContainerDiv = document.getElementById("tilesContainer");
    var tilesContainerDivOuter = document.getElementById("tilesContainerOuter");
    if (menuItemTypeExternal != "External") {
        tilesContainerDiv.className = "hideDiv";
        tilesContainerDivOuter.className = "hideDiv";
    }
    document.getElementById("linkArea").className = "displayDiv";

    // hide the PPOM tiles. If the PPOM menu was clicked, the PPOM menu software will run after the general menu
    // event handler runs and display the tiles.
    if (menuItemTypeExternal != "External") {
        ppomManager.displayPPOMTiles(false);
    }
    
    // There are no circumstances where this event handler (handleMenuClick) should set the content area to empty. 
    // If the user clicks on Home/Display Tiles, then the handleMenuClickForHom handler will set the content area
    // to empty and then display the tiles.
    if (divInnerHTML != "") {
        linkAreaDiv.innerHTML = divInnerHTML;
    }
    
    var menusDiv = document.getElementById("menus");
    var menuDivArray = menusDiv.getElementsByTagName("li"); // children of div with id "menus"
    for (i = 0; i < menuDivArray.length; i++) {
        if (menuDivArray[i].firstChild.getAttribute("class") != "menuText") {
            menuDivArray[i].className = "hideDiv";
        }
    }

    // Either go to external link URL (in a new tab), or do nothing with link since URL is #, and the 
    // appropriate links (given the link clicked on) are already displayed in the link area
    return true;
}

function showMenus() {
    // redisplay the menus after the user leaves the link area.
    var menusDiv = document.getElementById("menus");
    var menuDivArray = menusDiv.getElementsByTagName("li"); // children of div with id "menus"
    for (i = 0; i < menuDivArray.length; i++) {
        if (menuDivArray[i].firstChild.getAttribute("class") != "menuText") {
            menuDivArray[i].className = "displayDiv";
        }
    }
}

function handleMenuClickForPPOM(anchorTagItem) {
    document.getElementById("txtppomSearch").value = "";
    handleMenuClick(anchorTagItem);
    anchorTagItem.setAttribute("target", "");
    ppomManager.setPPOMTileText();
    ppomManager.displayPPOMTiles(true);
    ppomManager.currentPPOMTileID = "year0";
    var linkAreaDiv = document.getElementById("linkArea");
    linkAreaDiv.innerHTML = "<br />Retrieving PPOM links...<br /><br /><br /><br /><br /><br /><br /><br /><br /><br />";
    ppomAjax.GetPPOMMessages();
    return true;
}

function handleMenuClickForHome(anchorTagItem) {
    document.getElementById("linkArea").className = "hideDiv";
    document.getElementById("tilesContainer").className = "DisplayDiv";
    document.getElementById("tilesContainerOuter").className = "DisplayDiv";
    ppomManager.displayPPOMTiles(false);
    return false;
}

// The ppomManager object literalcontains methods used with the PPOM Tiles and Messages. It is a global object.
var ppomManager = {
    currentPPOMTileID: "",
    currentPPOMTileText: "",
    searchHitsTemp : [],    // contains indices of nested search hits in an array for a PPOM tile

    setPPOMEventHandlers: function () {
        var currentTile;
        for (var i = 0; i < numPPOMYears; i++) {
            currentTile = document.getElementById("year" + i);
            eventUtility.addEvent(currentTile, "click", this.handlePPOMTileClick);
        }
        currentTile = document.getElementById("yearOther");
        currentTile.onclick = this.handlePPOMTileClick;
        currentTile = document.getElementById("yearAll");
        currentTile.onclick = this.handlePPOMTileClick;
        currentTile = document.getElementById("searchTile");
        currentTile.onclick = this.handlePPOMSearchClick;
        currentTile.onkeypress = this.handlePPOMSearchKeypress;
        var searchTextBox = document.getElementById("txtppomSearch");
        searchTextBox.onkeypress = this.handlePPOMSearchKeypress;
        },

    handlePPOMSearchKeypress: function (eventObj) {
        var code = (eventObj.keyCode ? eventObj.keyCode : eventObj.which);
        // if enter key was pressed, start the search process
        if(code == 13) { 
            ppomManager.handlePPOMSearchClick(eventObj);
       }
    },

    handlePPOMSearchClick: function (eventObj) {
        var searchTextElement = document.getElementById("txtppomSearch");
        var searchText = searchTextElement.value;
        if (searchText == "") {
            alert("Please enter some text before searching.");
            searchTextElement.focus();
        } else {
            window.scrollTo(0, 0);          // bring right-side cursor to top of the page
            ppomManager.searchPPOMS(searchText);
        }
    },

    searchInResults: function(searchText) {
        this.searchHitsTemp.length = 0;
        // Copy contents of searchHits array (a set of indices) to empty searchHitsTemp array. The search will be done on the items
        // in the searchHitsTemp array and the hits will be returned to the searchHits array after clearing it.
        // Then the items in the searchHits array will be displayed in the table.
        for (i = 0; i < ppomYears.searchHits.length; i++) {
            this.searchHitsTemp.push(ppomYears.searchHits[i]);
        }
        ppomYears.searchHits.length = 0;
        // now do the search on the searchHitsTemp array
        for (i = 0; i < this.searchHitsTemp.length; i++) {
            ppomRow = ppomRows.ppomInfo[this.searchHitsTemp[i]];
    
            // this second param to Search Row is the index into the original ppomRows.ppomInfo item - this is the row
            // that's written to the searchHits array below. Remember that this index is stored in this.searchHitsTemp.
            this.searchRow(ppomRow, this.searchHitsTemp[i], searchText); 
        }
    },

    searchPPOMS: function (searchText) {
        var ppomRow;
        var i;
        if (this.currentPPOMTileID == "yearAll") {      // check if search on All Years
            if (ppomYears.searchHits.length > 0) {      // check if previous search for All Years exists
                this.searchInResults(searchText);       // puts search hit indices in ppomYears["searchHits"]
            } else {
                for (i = 0; i < ppomRows.ppomInfo.length; i++) {
                    ppomRow = ppomRows.ppomInfo[i];
                    this.searchRow(ppomRow, i, searchText);
                }
            }
        } else {
            if (ppomYears.searchHits.length > 0) {      // check if previous search for All Years exists
                this.searchInResults(searchText);       // puts search hit indices in ppomYears["searchHits"]
            } else {
                for (i = 0; i < ppomYears[this.currentPPOMTileID].length; i++) {
                    ppomRow = ppomRows.ppomInfo[ppomYears[this.currentPPOMTileID][i]];
                    this.searchRow(ppomRow, ppomYears[this.currentPPOMTileID][i], searchText);
                }
            }
        }
        this.displayPPOMSByYear("searchHits", searchText);
    },

    searchRow: function (ppomRow, i, searchText) {
        // i is the index of the current item in array that is being searched
        if (this.searchTextFound(ppomRow, searchText)) {
            ppomYears.searchHits.push(i);
        }
    },

    searchTextFound: function(ppomRow, searchText) {
        // this search is case insensitive
        if ( ppomRow["FN"].toLowerCase().indexOf(searchText.toLowerCase()) > -1 ||
                ppomRow["TL"].toLowerCase().indexOf(searchText.toLowerCase()) > -1 ||
                ppomRow["DU"].toLowerCase().indexOf(searchText.toLowerCase()) > -1 ) {
            return true;
        } else {
            return false;
        }
    },

    handlePPOMTileClick: function (eventObj) {
        // Because this is an event handler, it is treated as if owned by the element clicked on, and methods have to be called as a property of the
        // ppomManager object. So "this" cannot be used in this method to call other methods in the ppomManager object.
        var eSrc = eventUtility.getTarget(eventObj);

        // Reset search hits array when any PPOM tile is clicked. This ensures searching is done for all PPOMS for the tile just clicked.
        // This is also reset when the main PPOM menu item is clicked.
        ppomYears.searchHits.length = 0;

        // Save PPOMID value for use with Search
        // Note that the id for year0 is set in handleMenuClickForPPOM
        ppomManager.currentPPOMTileID = eSrc.id;
        ppomManager.currentPPOMTileText = document.getElementById(eSrc.id).innerHTML;
        ppomManager.setDefaultColorsForPPOMTiles();
        eSrc.style.color = "black";
        eSrc.style.backgroundColor = "gold";
        window.scrollTo(0, 0);          // bring right-side cursor to top of the page
        if (eSrc.id == "yearAll") {
            ppomManager.displayAllPPOMS();
        } else {
            ppomManager.displayPPOMSByYear(eSrc.id);
        }
    },

    setDefaultColorsForPPOMTiles: function () {
        var ppomTiles = document.getElementsByClassName("PPOMYear");
        for (var i = 0; i < ppomTiles.length; i++) {
            ppomTiles[i].style.color = "gold";
            ppomTiles[i].style.backgroundColor = "black";
        }
    },

    setPPOMTileText: function () {
        // First set the text (year) for the PPOM tiles. Note that the last two (Other and All
        // are hard-coded in the HTML. Use a global boolean so this is only done once.
        if (!yearTextSet) {
            yearTextSet = true;
            // currentYear value is set in js/config.js
            currentYear = configItems.ppomCurrentYear;
            if (!currentYear) {
                currentYear = (new Date()).getFullYear();
            }

            var currentTile;
            for (var i = 0; i < numPPOMYears; i++) {
                currentTile = document.getElementById("year" + i.toString());
                currentTile.innerHTML = currentYear - i;
            }
        }
    },

    displayPPOMTiles: function (display) {
        // display is a boolean parameter; true to display the PPOM tiles; false to hide them

        if (display == true) {
            // add additional height to the fixed area to show the PPOM tiles below the menus
            var fixedContentDiv = document.getElementById("fixedContent");
            fixedContentDiv.style.height = "185px";

            // adjust the scrollable content to show the PPOM tiles
            var scrollableContentDiv = document.getElementById("scrollableContent");
            scrollableContentDiv.style.top = "180px";

            // make the PPOM tiles visible
            var PPOMYearsDiv = document.getElementById("PPOMYears");
            PPOMYearsDiv.style.display = "block";

            // make search text box and button visible
            var PPOMSearchDiv = document.getElementById("ppomSearch");
            PPOMSearchDiv.style.display = "block";

            var PPOMSearchTile = document.getElementById("searchTile");
            PPOMSearchTile.style.display = "block";
        } else {
            // remove additional height from the fixed area 
            var fixedContentDiv = document.getElementById("fixedContent");
            fixedContentDiv.style.height = "140px";

            // adjust the scrollable content when hiding the PPOM tiles
            var scrollableContentDiv = document.getElementById("scrollableContent");
            scrollableContentDiv.style.top = "135px";

            // remove the PPOM tiles from the UI
            var PPOMYearsDiv = document.getElementById("PPOMYears");
            PPOMYearsDiv.style.display = "none";

            var PPOMSearchDiv = document.getElementById("ppomSearch");
            PPOMSearchDiv.style.display = "none";

            var PPOMSearchTile = document.getElementById("searchTile");
            PPOMSearchTile.style.display = "none";
        }
    },

    assignPPOMYears: function () {
        // Get the 4 digit year from the name of the PPOM, and then derive an index 
        // (like "year0" for the ppom arrays (one for each tile). If the ppom year returned
        // from getPPOMYear is -1 or if the difference between the current year and the
        // ppomYear is greater than 4, then set the index to "yearOther".
        // To get the numeric value following "year", subtract the ppomYear from the current year.\
        // For example, if the current year is 2017 and the ppomYear is 2017, then 2017 - 2017 is
        // 0, and the index is "year0". Similarly, if the current year is 2017 and the ppom year is
        // 2016, then 2017 - 2017 is 1, and the drived index is "year1".
        //
        // Once the index is derived, use this to index into the appropriate property in ppomYears
        // and add the index i value (from traversing all the ppom rows) to the array corresponding to
        // this property.
        var ppomYear;
        var ppomIndex;
        this.clearPPOMYears();      // clear out arrays of PPOM items before setting them to latest DB values
        if (ppomRows.ppomInfo.length >= 0 && ppomRows.ppomInfo[0].FID == "-999") {
            // -999 means an error occurred, so assign the PPOM to year0 and in other code display the error message
            ppomYears["year0"].push(0);
        } else {
            // assign each PPOM index to the appropriate array
            for (i = 0; i < ppomRows.ppomInfo.length; i++) {
                ppomYear = this.getPPOMYear(ppomRows.ppomInfo[i].FN);
                if (ppomYear == -1) {
                    ppomIndex = "yearOther";
                } else {
                    if ((currentYear - ppomYear) > 4) {
                        ppomIndex = "yearOther";
                    } else {
                        ppomIndex = "year" + (currentYear - ppomYear);
                    }
                }
                ppomYears[ppomIndex].push(i);
            }
        }
    },

    clearPPOMYears: function () {
        for (var ppomYear in ppomYears) {
            ppomYears[ppomYear].length = 0;
        }
    },

    getPPOMYear: function (ppomName) {
        // code assumes valid PPOM format (from db call) is: "PPOM YY-NNN" 
        // If the format is valid, return the 2 digit year (as a string) ; if not, return "-1";
        var year = -1;
        var regex = /^PPOM \d\d-\d\d\d/;
        if (regex.test(ppomName)) {
            year = 2000 + parseInt(ppomName.substr(5, 2), 10);
        }
        return year;
    },

    displayAllPPOMS: function () {
        var linkAreaDiv = document.getElementById("linkArea");
        linkAreaDiv.innerHTML = "";
        var linkAreaHTML = "";

        if (ppomRows.ppomInfo[0].FID == "-999") {   // assume an error message will be in row 0 (based on prior code that sets up row 0)
            linkAreaHTML += "<ul id='ppomNames'><li class=ppomList><span>" + ppomRows.ppomInfo[0].FN + "</span></li></ul>";
        } else {
            linkAreaHTML = this.setupTableAndHeaderRow(linkAreaHTML);
            for (var i = 0; i < ppomRows.ppomInfo.length; i++) {
                linkAreaHTML += 
                    "<tr><td><a target='_blank' href=" + configItems.displayPPOMDataURLBase + "?param1=" +
                    ppomRows.ppomInfo[i].FID + ">" + ppomRows.ppomInfo[i].FN + "</a></td>" +
                    "<td>" + ppomRows.ppomInfo[i].TL + "</td>" +
                    "<td class=ppomDateTD>" + ppomRows.ppomInfo[i].DU + "</td></tr>";
            }
            linkAreaHTML += "</table>";
        }
        linkAreaDiv.innerHTML = linkAreaHTML;
    },

    displayPPOMSByYear: function (ppomTileId, searchText) {
        // searchText parameter will be supplied if displayPPOMSByYear was called by the searchPPOMS method.
        // Otherwise it will be underined and the code below converts it to an empty string for use below.
        if (searchText == undefined) {
            searchText = "";
        }
        var linkAreaDiv = document.getElementById("linkArea");
        linkAreaDiv.innerHTML = "";
        var linkAreaHTML = "";
        var startingHTMLForMessage = "<ul id='ppomNames'><li class=ppomList><span>";

        if (ppomRows.ppomInfo[0].FID == "-999") {   // assume an error message will be in row 0 (based on prior code that sets up row 0)
            linkAreaHTML += startingHTMLForMessage + ppomRows.ppomInfo[0].FN + "</span></li></ul>";
        } else if (ppomYears[ppomTileId].length == 0 && ppomTileId != "searchHits") {
            linkAreaHTML += 
                startingHTMLForMessage + "There are no PPOM messages for " + this.currentPPOMTileText + ".</span></li></ul>";
        } else if (ppomYears[ppomTileId].length == 0) {
            linkAreaHTML += startingHTMLForMessage + "There was no data found for the current search text.</span></li></ul>";
        } else {
            linkAreaHTML = this.setupTableAndHeaderRow(linkAreaHTML);
            for (var i = 0; i < ppomYears[ppomTileId].length; i++) {
                linkAreaHTML +=
                    "<tr><td><a target='_blank' href=" +configItems.displayPPOMDataURLBase + "?param1=" +
                    ppomRows.ppomInfo[ppomYears[ppomTileId][i]].FID + ">" + ppomRows.ppomInfo[ppomYears[ppomTileId][i]].FN.highlight(searchText) + "</a></td>" +
                    "<td>" +ppomRows.ppomInfo[ppomYears[ppomTileId][i]].TL.highlight(searchText) + "</td>" +
                    "<td class=ppomDateTD>" +ppomRows.ppomInfo[ppomYears[ppomTileId][i]].DU.highlight(searchText) + "</td></tr>";
            }
            linkAreaHTML += "</table>";
        }
        linkAreaDiv.innerHTML = linkAreaHTML;
    },

    setupTableAndHeaderRow: function (linkAreaHTML) {
        // create table for PPOM display and add header row
        linkAreaHTML += "<table class='ppomTable'>" +
         "<tr><th class='ppomNameTH'>PPOM Name</th><th class='ppomTagLineTH'>Tag Line</th><th class='ppomDateTH'>Upload Date</th>";
        return linkAreaHTML;
    }
};

String.prototype.highlight = function (searchText) {
    // This methods inserts <span> tags around the search text. The <span> tag includes a class of 'hl' that css uses to highlight the text.
    // Because string functions are case sensitive, this function works by finding the position of the search text (in a lower case version
    // of the original string, and using the substr function to get the string from the original text by position and replacing that one
    // to preserve case.
    var ppomText = this.toString();
    if (searchText != "") {         // if there was no search, then just return the original text to display
        var ppomTextLower = ppomText.toLowerCase();
        var searchTextLower = searchText.toLowerCase();
        var searchTextLen = searchTextLower.length;
        //var textToReplace = "";          // the case-sensitive version of the search Text
        var startSearch = 0;             // start at 0, search will work from left to right since the replace function only works on the first source param
        var foundTextPos = 0;
        var stringPart;                 // part of the ppom string, ends with the search text to be highlighted
        var foundTextPosArray = [];        // contains each part of the string where the search text was found
        //var foundTextStringArray = [];
        var stringPartForReplace;
        var newPPOMText = "";

        // loop through the PPOM string, putting the index of each position where the searchText was found into the foundTextArray
        while (startSearch < ppomTextLower.length) {      
            foundTextPos = ppomTextLower.indexOf(searchTextLower, startSearch);
            if (foundTextPos > -1) {
                foundTextPosArray.push({ start: startSearch, foundPos: foundTextPos});
                startSearch = foundTextPos + searchTextLen;
            } else {
                break;
            }
        }

        if (foundTextPosArray.length > 0) {
        // break up the original PPOM String (not the lower case version) into pieces
            for (var i = 0; i < foundTextPosArray.length; i++) {
                stringPart = ppomText.substring(foundTextPosArray[i].start, foundTextPosArray[i].foundPos + searchTextLen);
                stringPartForReplace = ppomText.substr(foundTextPosArray[i].foundPos, searchTextLen);
                newPPOMText += stringPart.replace(stringPartForReplace, "<span class='hl'>" + stringPartForReplace + "</span>");
            }
            newPPOMText += ppomText.substring(foundTextPosArray[i - 1].foundPos + searchTextLen);
        } else {
            newPPOMText = ppomText;
        }
    } else {
        newPPOMText = ppomText;
    }
    return newPPOMText;
}

var ppomAjax = {
        GetPPOMMessages: function () {
        var policyPrefix = "PPOM";
        var params = "{'policyPrefix':'" + policyPrefix + "'}";
        ppomManager.setDefaultColorsForPPOMTiles();
        $.ajax({
                type: "POST",
                url: configItems.getPPOMMessagesURL,
                data: params,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: this.processResults,
                failure: function (response) {
                alert(response.d);
        }
        });
},

        processResults: function (response) {
        var linkAreaDiv = document.getElementById("linkArea");
        var linkAreaHTML = "";
        linkAreaDiv.innerHTML = "";
        try {
            ppomRows = JSON.parse(response.d);  // convert JSON array to global JS array of objects
        } catch (exception) {
            ppomRows = null;
            linkAreaDiv.innerHTML = "<br />PPOM data returned from the database contains invalid formatting characters and cannot be diplayed." +
                "<br /><br />Please call the Help Desk for assistance at " + configItems.helpDeskPhone + "." +
                "<br /><br /><br /><br /><br /><br /><br /><br />";
            return;
        }
        ppomManager.assignPPOMYears();
        var ppomYear0Tile = document.getElementById("year0");
        ppomYear0Tile.style.color = "black";
        ppomYear0Tile.style.backgroundColor = "gold";
        ppomManager.currentPPOMTileText = ppomYear0Tile.innerHTML;
        ppomManager.displayPPOMSByYear("year0");
    }
};

// execute the init function after the page loads
window.onload = init;
