﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace PPOMManager
{
    public class PPOMAccess
    {

        public void DummyMethod(string dummyParam)
        {
            string a = dummyParam;
        }

        public DataTable GetPPOMMessagesFromDB(string policyPrefix, string connectionString, ref string errorMessage)
        {
            // In PolicyFilter3.dll this method was named GetFromDB().
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand sqlCommand = new SqlCommand();
            SqlDataAdapter sqlDataAdapter1 = new SqlDataAdapter();
            try
            {
                DataSet dataSet = new DataSet();
                string str = "smms.GetMessages";
                sqlCommand.Parameters.Add("@LibType", SqlDbType.NVarChar, 20).Value = policyPrefix; //(object)this.policyPrefix; - this was the original value in PolicyFilter3.dll
                sqlConnection.ConnectionString = connectionString;
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = str;
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlDataAdapter1.SelectCommand = sqlCommand;
                sqlDataAdapter1.Fill(dataSet);
                //Console.WriteLine("Get PPOMMessagesFromDB: Return dataset with " + dataSet.Tables[0].Rows.Count.ToString());
                return dataSet.Tables[0];
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return (DataTable)null;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public DataTable GetPPOMAttachmentsFromDB(string policyPrefix, string connectionString)
        {
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand sqlCommand = new SqlCommand();
            SqlDataAdapter sqlDataAdapter1 = new SqlDataAdapter();
            //SqlDataAdapter sqlDataAdapter2 = new SqlDataAdapter();
            try
            {
                DataSet dataSet = new DataSet();
                string str = "smms.GetMessageAttachments";
                sqlCommand.Parameters.Add("@LibType", SqlDbType.NVarChar, 20).Value = policyPrefix; // (object)this.policyPrefix; this was in the original code
                sqlConnection.ConnectionString = connectionString;
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = str;
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlDataAdapter1.SelectCommand = sqlCommand;
                sqlDataAdapter1.Fill(dataSet);
                //Console.WriteLine("GetAttachmentsFromDB: Return dataset with " + dataSet.Tables[0].Rows.Count.ToString());
                return dataSet.Tables[0];
            }
            catch (Exception ex)
            {
                //this.Controls.Add((Control)new Label()
                //{
                //    Text = ex.Message
                //});
                //Console.WriteLine(ex.Message);
                return (DataTable)null;
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }
}
