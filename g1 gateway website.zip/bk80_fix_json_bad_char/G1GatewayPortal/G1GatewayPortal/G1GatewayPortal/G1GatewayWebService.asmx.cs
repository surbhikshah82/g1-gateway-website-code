﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using PPOMManager;
using System.Text;
using System.Configuration;



namespace G1GatewayPortal
{


    // the following code was copied from G1GatewayWebMethods
    /// <summary>
    /// Use a WebMethod to call a stored procedure to get the PPOM metadata from the database and then reformat
    /// the dataset containing the PPOM data as an array of JSON object and then pass this back to the 
    /// calling web page. Note that this Web Method is called through AJAX implemented by jQuery in the JavaScript
    /// for an HTML5 page, not an ASP.NET page.
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class G1GatewayWebService : System.Web.Services.WebService
    {
        [WebMethod]
        public string HelloWorld(string name)
        {
            return "Hello " + name + "from the PPOM HelloWorld WebMethod";
        }

        [WebMethod]
        public string GetPPOMMessages(string policyPrefix)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ppomConnectionString"].ToString();
            PPOMAccess ppomAccess = new PPOMAccess();
            string errorMessage = "";
            DataTable dt = ppomAccess.GetPPOMMessagesFromDB(policyPrefix, connectionString, ref errorMessage);
            
             

            if (dt == null)
            {
                string displayError = ConfigurationManager.AppSettings["displayError"].ToString();
                string errorString = "";
                if (!String.IsNullOrEmpty(errorMessage) && displayError == "1")
                {
                    //errorMessage = errorMessage.Replace("SQL Server", "\"SQL Server\"");

                    //This code substitues the error message into the json string but fails
                    errorMessage = errorMessage.Replace('"', '\'');
                    errorMessage = errorMessage.Replace("\r\n", " ");
                    errorString = "{\"ppomInfo\":" +
                        "[" +
                            "{\"FN\":\"errorMessage\", \"FID\": \"-999\"}" +
                        "]" +
                    "}";
                    errorString = errorString.Replace("errorMessage", errorMessage);

                    return errorString;
                }
                else
                {
                    errorString = "{\"ppomInfo\":" +
                      "[" +
                          "{\"FN\":\"" + "There is no data. An error occurred." + "\", \"FID\": \"-999\"}" +
                      "]" +
                  "}";
                    return errorString;
                }
            }
            else
            {
                // Sort and filter the data table returned from the proc. This means that
                // the code below will work with an array of DataRow objects instead of a data table.
                // The first parameter to the Select method is the SQL string specifying the filter for
                // the data table, and the second parameter is the SQL string specifying the sort.

                //old code of barrys
                //DataRow[] rows = dt.Select("FileLeafRef LIKE '%pdf'", "FileLeafRef DESC");

                //new code to filter files
                string filefilter = "FileLeafRef LIKE '%pdf' or FileLeafRef  LIKE '%doc' OR FileLeafRef  LIKE '%docx'";
                // string filefilter = "FileLeafRef  LIKE '*.' ";
                //Sort the column in Descending Order: New first.
                string sortexpression = ("FileLeafRef DESC");
                 
                DataRow[] rows = dt.Select(filefilter, sortexpression);
                StringBuilder jsonDT = new StringBuilder(); // DT stands for data table
                string ppomName = "";
                if (rows.Length > 0)
                {
                    int startRow;
                    int endRow;

                    // get the start and end rows for converting to Json based on values in the web config file.
                    // If lastRowsNumber (in web.config) is not empty, use this number to determine the start and end rows.
                    // If it is empty, use the startRow and endRow values in web.config. Note that the dataset is already
                    // sorted above by PPOM name (column name is FileLeafRef) in descending order, so the lastRowsNumber
                    // will get the first rows from the dataset.
                    string strLastRowsNumber = ConfigurationManager.AppSettings["lastRowsNumber"];

                    if (!String.IsNullOrEmpty(strLastRowsNumber))
                    {
                        int lastRowsNumber = Int32.Parse(strLastRowsNumber);
                        if (rows.Length > lastRowsNumber)
                        {
                            startRow = 0;
                            endRow = lastRowsNumber;
                        }
                        else
                        {
                            startRow = 0;
                            endRow = rows.Length;
                        }
                    }
                    else
                    {
                        startRow = Int32.Parse(ConfigurationManager.AppSettings["startRow"]);
                        endRow = Int32.Parse(ConfigurationManager.AppSettings["endRow"]);
                        if (endRow == 99999)
                        {
                            endRow = rows.Length;
                        }
                        else
                        {
                            if (endRow > rows.Length)
                            {
                                endRow = rows.Length;
                            }
                        }
                    }

                    int jsonRowCount = 0;
                    jsonDT.Append("{\"ppomInfo\":[");
                    for (int i = startRow; i <= (endRow - 1); i++)
                    {
                        ppomName = rows[i]["FileLeafRef"].ToString();
                        if (jsonRowCount > 0)
                        {
                            // put comma before each valid item after the first one; This handles issue of the final items not ending in ".pdf"
                            jsonDT.Append(",");
                        }
                        jsonDT.Append("{\"FN\":\"" + rows[i]["FileLeafRef"] +                                           // PPOM Name
                                        "\",\"FID\":\"" + rows[i]["FileStorageID"] +                                    // ID used with DisplayPPOM app
                                        "\",\"TL\":\"" + rows[i]["metadata"] +                                          // Tag Line (metadata)
                                        "\",\"DU\":\"" + Convert.ToDateTime(rows[i]["metadate"]).ToString("MM/dd/yy")   // Date Updated
                                        + "\"}");
                        jsonRowCount++;
                    }
                    jsonDT.Append("]}");
                }

                return jsonDT.ToString().Replace("\n", " ");

                // keep the commented out code here in case we need to test a hardcoded JSON string.
                //string testString = "{\"ppomInfo\":" +
                // "[" +
                //     "{\"FN\":\"paris\", \"FID\": \"15\"}," +
                //     "{\"FN\":\"helen\", \"FID\": \"13\"}" +
                // "]" +
                //"}";
                //testString = testString.Replace("paris", dt.Rows.Count.ToString());
                //return testString;
            }
        }
    }

}


