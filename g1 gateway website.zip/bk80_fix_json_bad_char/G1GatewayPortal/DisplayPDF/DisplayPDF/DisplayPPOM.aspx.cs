﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
 
using System.IO;
 
 
namespace DisplayPDF
{
    public partial class DisplayPPOM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    // sanitize query string by converting it to an int; anything else will cause an exception
                    int fileID = int.Parse(Request.QueryString[0]);
                    View(fileID);
                    ProcessRequest2(HttpContext.Current);
                }
                catch (SystemException ex)
                {
                    string displayError = ConfigurationManager.AppSettings["displayError"].ToString();
                    if (displayError == "1")
                    {
                         ProcessRequest2(HttpContext.Current);
                        //use below error message for specifc error message
                        //Label1.Text += ex.Message;
                         Label1.Text += "There is no data. An error occurred";
                    }
                    else 
                    {

                        //ProcessRequest2(HttpContext.Current);
                         Label1.Text += "There is no data. An error occurred";
                        
                    }
                }
            }
        }

        protected void View(int fileID)
        {
            //originial code of barry. We cant use this because Word document cannot be embeded.

            //string embed = "<object id=\"obj1\" data=\"{0}{1}\" type=\"application/pdf\"  >";
            ////embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            ////embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            //embed += "</object>";

             ProcessRequest2(HttpContext.Current);
        }

        public void ProcessRequest2(HttpContext context)
        {
            int id = int.Parse(context.Request.QueryString[0]);
        
            byte[] bytes;
            string constr = ConfigurationManager.ConnectionStrings["ppomConnectionString"].ConnectionString;
            string filename;
             
             
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@FileID", id);
                     cmd.CommandText = "smms.GetPPOM";
                                                         
                    using (SqlDataReader sdr2 = cmd.ExecuteReader())
                    {
                          
                        sdr2.Read();
                        bytes = (byte[])sdr2["Binary"];
                        filename = sdr2["FileName"].ToString();
                        //fileobj = sdr2["FileName"];
             
             
                    }
                    
            
                    con.Close();
                    //Label1.Text += bytes.Length.ToString() + " bytes from db <br />";
                }
            }

            if (filename.Substring(filename.IndexOf('.') + 1).ToLower() == "pdf")
            {
                context.Response.Buffer = true;
                context.Response.Clear();
                context.Response.ContentType = "application/pdf";
                context.Response.BinaryWrite(bytes);
                context.Response.Flush();
                context.Response.End();
                 
            }


            else if (filename.Substring(filename.IndexOf('.') + 1).ToLower() == "doc")
            {
                context.Response.Buffer = true;
                context.Response.Clear();
                context.Response.ClearHeaders();
                context.Response.AddHeader("content-disposition", "attachment; filename=\"" + filename);
                context.Response.ContentType = "application/msword";
                context.Response.BinaryWrite(bytes);
                context.Response.Flush();
                context.Response.End();
            }


            else if (filename.Substring(filename.IndexOf('.') + 1).ToLower() == "docx")
            {
                context.Response.Buffer = true;
                context.Response.Clear();
                context.Response.ClearHeaders();
                context.Response.AddHeader("content-disposition", "attachment; filename=\"" + filename);
                context.Response.ContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                 context.Response.BinaryWrite(bytes);
                context.Response.Flush();
                context.Response.End();
                 
            }
            
           
        }

       
    }

}


